// Server.java
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;
import java.lang.Math;

public class Server
{
	public static void main(String args[]) throws IOException
	{

		// Step 1: Establish the socket connection.
		ServerSocket ss = new ServerSocket(4444);
		System.out.println("Waiting for connection request from client ..." + "\n");
		
		Socket s = ss.accept();
		
		System.out.println("Connection has been established!" + "\n");
		// Step 2: Processing the request.
		DataInputStream dis = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());

		while (true)
		{
			// wait for input
			String input = dis.readUTF();

			if(input.equals("exit"))
				break;
			double result;
			System.out.println("Value received in degree: " + input);
			result = Integer.parseInt(input)/180;
			
			result = result*3.14;
			System.out.println("Sending the result...");

			// send the result back to the client.
			dos.writeUTF(Double.toString(result));
		}
	}
}

