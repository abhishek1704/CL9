import java.net.InetAddress;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.Scanner;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


class Server {

	public static void main(String[] args) throws IOException {
	
		ServerSocket ss = new ServerSocket(4444);
		Socket s = ss.accept();
		
		DataInputStream dis = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		

		while (true) {
		
			String name = dis.readUTF();
			if (name == "exit") {
				break;
			}	
			
			dos.writeUTF("Hello " + name + "!");
			
		}
	}

}
