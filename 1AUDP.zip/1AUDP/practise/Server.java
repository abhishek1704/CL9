import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;
import java.util.Scanner;
import java.net.InetAddress;

public class Server {

	public static void main(String[] args) throws IOException {
		
		Scanner sc = new Scanner(System.in);
		byte[] sendbuff = new byte[65535];
		byte[] recbuff = new byte[65535];
		
		DatagramSocket ds = new DatagramSocket(1234);
		InetAddress ip = null;
		int port;
		
		DatagramPacket inpacket = null;
		DatagramPacket outpacket = null;
		
		while (true) {

			inpacket = new DatagramPacket(recbuff, recbuff.length);
			ds.receive(inpacket);
			String s = new String(inpacket.getData(), 0, inpacket.getLength());
			
			if (s.equals("exit")) {
				break;
			}
			
		    String inp = "Hello " + s;
			sendbuff = inp.getBytes();			
			
			ip = inpacket.getAddress();
			port = inpacket.getPort();
			outpacket = new DatagramPacket(sendbuff, sendbuff.length, ip, port);
			ds.send(outpacket);
			
		}
	
	}
}
