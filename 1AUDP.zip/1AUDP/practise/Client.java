import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.io.IOException;
import java.util.Scanner;
import java.net.InetAddress;

public class Client {

	public static void main(String[] args) throws IOException {
		
		Scanner sc = new Scanner(System.in);
		byte[] sendbuff = new byte[65535];
		byte[] recbuff = new byte[65535];
		
		DatagramSocket ds = new DatagramSocket();
		InetAddress ip = InetAddress.getLocalHost();
		
		DatagramPacket inpacket = null;
		DatagramPacket outpacket = null;
		
		while (true) {
			String inp = sc.nextLine();
			
			sendbuff = inp.getBytes();			
			outpacket = new DatagramPacket(sendbuff, sendbuff.length, ip, 1234);
			ds.send(outpacket);
			
			inpacket = new DatagramPacket(recbuff, recbuff.length, ip, 1234);
			ds.receive(inpacket);
			// String response = new String(DpReceive.getData(),0,DpReceive.getLength());
			String response = new String(inpacket.getData(), 0, inpacket.getLength());
			System.out.println("The response from the server is: " + response);
			
		}
	
	}
}
